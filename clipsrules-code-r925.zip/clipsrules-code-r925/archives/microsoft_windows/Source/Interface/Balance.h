void Balance(HWND);
void LoadBatchBufferSelection(HWND,int);
void EditComplete(HWND);
void DoComment(HWND);
void DoUncomment(HWND);
  
