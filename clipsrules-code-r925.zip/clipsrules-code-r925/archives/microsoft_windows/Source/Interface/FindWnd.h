HMENU findWindowMenu(HMENU hMenu);
